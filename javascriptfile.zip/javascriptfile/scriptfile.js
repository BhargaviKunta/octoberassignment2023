const str = 'hello this bhargavi kunta';
const displayReverseSentence = (s) => {
   const a = s.split(" ");
   const reversed = a.map(element => {
      return element.split('').reverse().join("");
   });
   return reversed.join(" ");
};
console.log(displayReverseSentence(str));