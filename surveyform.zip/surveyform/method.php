<?php
 
        $servername="localhost";
        $username="root";
        $password="";
        $dbname = "localdata";
        $conn = mysqli_connect("localhost", "root", "", "localdata");
         
        // Check connection
        if($conn === false){
            die("ERROR: Could not connect. "
                . mysqli_connect_error());
        }
         
        // Taking all 5 values from the form data(input)
        $first_name = $_REQUEST['firstname'];
        $last_name = $_REQUEST['lastname'];
        $email = $_REQUEST['emailid'];
        $phonenumber=$_REQUEST['phone'];
        $gender= $_REQUEST['check'];
        $profession=$_REQUEST['profession'];
        $dateofbirth=$_REQUEST['birthday'];
        $country=$_REQUEST['country'];
       
         
        // Performing insert query execution
        // here our table name is college
        $sql = "INSERT INTO registerform  VALUES ('$first_name', 
            '$last_name','$email','$phonenumber','$gender','$profession','$dateofbirth','$country')";
         
        if(mysqli_query($conn, $sql)){
            echo "<h3>data stored in a database successfully."
                . " Please browse your localhost php my admin"
                . " to view the updated data</h3>"; 
 
            echo nl2br("\n$first_name\n $last_name\n "
                . "$gender\n $profession\n $email\n $country \n$dateofbirth");
        } else{
            echo "ERROR: Hush! Sorry $sql. "
                . mysqli_error($conn);
        }
        If(isset($_POST['reset'])){
            $_POST = array();
          }
         
        // Close connection
        mysqli_close($conn);
        ?>